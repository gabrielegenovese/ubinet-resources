Adaptive Streaming Server and Client code
========================================

Author: Parishit Juluri

A simple Adaptive streaming client and server model.

Server:
      Hosts the MPD file and the video/audio reprsentations

Client:
      Downloads all the representations of the videos paralally.
